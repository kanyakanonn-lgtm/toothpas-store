// Google Apps Script: วางใน Extensions > Apps Script ของ Google Sheet
// Deploy > New deployment > Web app; Execute as: Me; Who has access: Anyone
function doPost(e) {
  const payload = JSON.parse(e.postData.contents);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const name = payload.type === "Products" ? "Products" : "Orders";
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.appendRow(name === "Orders"
      ? ["Order ID","Customer","Phone","Address","SKU","Product","Qty","Unit Price","Total","Status","Created At"]
      : ["SKU","Product","Description","Price","Stock","Color"]);
  }
  const d = payload.data;
  const row = name === "Orders"
    ? [d.id,d.customer,d.phone,d.address,d.sku,d.productName,d.qty,d.unitPrice,d.total,d.status,d.createdAt]
    : [d.sku,d.name,d.desc,d.price,d.stock,d.color];
  sh.appendRow(row);
  return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
}
