# ละมุน SOAP — Student Logistics Project

## สิ่งที่มีในโปรเจกต์
- Landing page ร้านสบู่ภาษาไทย พร้อมสินค้า 2 SKU
- ฟอร์มรับคำสั่งซื้อและตรวจสอบสต็อก
- รายการออเดอร์และ Picking List
- ปรับสต็อกสินค้า
- สร้าง/พิมพ์ใบปะหน้าพัสดุ
- บันทึกข้อมูลใน browser localStorage
- ตัวเลือกส่งข้อมูลไป Google Sheets ผ่าน Apps Script

## เปิดใช้งาน
เปิด `index.html` ในเบราว์เซอร์ได้เลย หรืออัปโหลดทั้งโฟลเดอร์ไป GitHub แล้ว Import Repository ใน Vercel (Framework Preset: Other, Build Command ว่าง, Output Directory `.`)

## เชื่อม Google Sheets
1. สร้าง Google Sheet ใหม่
2. Extensions > Apps Script
3. วางโค้ดจาก `google-apps-script.gs`
4. Deploy > New deployment > Web app
5. Execute as: Me; Who has access: Anyone
6. Deploy และคัดลอก Web app URL
7. วาง URL ในแท็บ Google Sheets ของเว็บไซต์

หมายเหตุ: Google Drive/Sheets connector อาจถูกจำกัดโดยผู้ดูแลบัญชี แต่การตั้งค่า Apps Script ทำผ่านบัญชี Google ในเบราว์เซอร์ได้

## โครงสร้าง
- `index.html` เว็บไซต์ทั้งหมด
- `google-apps-script.gs` ตัวรับข้อมูลไป Google Sheets
- `images/` โฟลเดอร์สำหรับใส่รูปสินค้า (เพิ่มรูปจริงได้ภายหลัง)

## ข้อมูลตัวอย่าง
- SOAP-001 สบู่ข้าวโอ๊ต ราคา 89 บาท สต็อก 40
- SOAP-002 สบู่น้ำผึ้ง ราคา 99 บาท สต็อก 35

ข้อมูลสินค้าและจำนวนสต็อกเป็นข้อมูลสมมติสำหรับงานเรียน ควรแก้ไขให้ตรงกับสินค้าจริงก่อนนำไปใช้
